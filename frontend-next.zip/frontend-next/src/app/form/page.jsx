// src/app/form/page.jsx
'use client'

import DishForm from '../components/DishForm'

export default function FormPage() {
  return <DishForm />
}
