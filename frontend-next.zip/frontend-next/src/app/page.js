// src/app/page.jsx
import DishList from "./components/DishList";

export default function HomePage() {
  return <DishList />
}
