// src/app/components/Header.jsx
'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Button } from '../../components/ui/button'
import { motion } from 'framer-motion'

export default function Header() {
  const path = usePathname()

  const menuItems = [
    { href: '/', label: 'Pratos' },
    { href: '/form', label: 'Cadastro' },
  ]

  return (
    <header className="bg-white shadow">
      <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
        <h1 className="text-2xl font-bold">🍽️ Restaurante</h1>
        <div className="flex space-x-2">
          {menuItems.map(item => {
            const isActive = path === item.href
            return (
              <Link key={item.href} href={item.href} passHref>
                <Button
                  asChild
                  variant={isActive ? 'default' : 'outline'}
                  size="sm"
                >
                  <motion.span
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    transition={{ duration: 0.2 }}
                  >
                    {item.label}
                  </motion.span>
                </Button>
              </Link>
            )
          })}
        </div>
      </nav>
    </header>
  )
}
