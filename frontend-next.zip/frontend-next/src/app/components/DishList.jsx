// src/app/components/DishList.jsx
'use client'

import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { useEffect, useState } from 'react'
import api from '../utils/api'

export default function DishList() {
  const [dishes, setDishes] = useState([])

  useEffect(() => {
    api.get('/dishes').then(res => setDishes(res.data))
  }, [])

  const handleDelete = async (id) => {
    await api.delete(`/dishes/${id}`)
    setDishes(ds => ds.filter(d => d.id !== id))
  }

  return (
    <div className="grid gap-4">
      {dishes.map(d => (
        <motion.div
          key={d.id}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.2 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>{d.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-2 text-sm text-gray-600">{d.description}</p>
              <div className="flex justify-between items-center">
                <span className="font-semibold">R$ {d.price.toFixed(2)}</span>
                <div className="space-x-2">
                  <Button size="sm" variant="outline" asChild>
                    <Link href={`/form?id=${d.id}`}>Editar</Link>
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => handleDelete(d.id)}>
                    Excluir
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  )
}
