// src/app/components/DishForm.jsx
'use client'

import { Input } from '../../components/ui/input'
import { Textarea } from '../../components/ui/textarea'
import { Button } from '../../components/ui/button'
import { useRouter, useSearchParams } from 'next/navigation'
import { useEffect, useState } from 'react'
import api from '../utils/api'

export default function DishForm() {
  const router = useRouter()
  const params = useSearchParams()
  const id = params.get('id')

  const [form, setForm] = useState({ name: '', description: '', price: '' })

  useEffect(() => {
    if (id) {
      api.get(`/dishes/${id}`).then(res => {
        setForm(res.data)
      })
    }
  }, [id])

  const handleChange = e => {
    const { name, value } = e.target
    setForm(f => ({ ...f, [name]: value }))
  }

  const handleSubmit = async e => {
    e.preventDefault()
    const payload = { ...form, price: parseFloat(form.price) }

    if (id) await api.put(`/dishes/${id}`, payload)
    else await api.post('/dishes', payload)

    router.push('/')
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-w-md mx-auto">
      <div>
        <label className="block text-sm font-medium">Nome</label>
        <Input name="name" value={form.name} onChange={handleChange} required />
      </div>
      <div>
        <label className="block text-sm font-medium">Descrição</label>
        <Textarea name="description" value={form.description} onChange={handleChange} />
      </div>
      <div>
        <label className="block text-sm font-medium">Preço</label>
        <Input
          name="price"
          type="number"
          step="0.01"
          value={form.price}
          onChange={handleChange}
          required
        />
      </div>
      <Button type="submit" className="w-full">
        {id ? 'Atualizar prato' : 'Criar prato'}
      </Button>
    </form>
  )
}
