import { test, expect } from '@playwright/test';

// Executa os testes em série para garantir fluxo CRUD
test.describe.serial('Restaurant App - CRUD de Pratos', () => {
  const BASE_URL = process.env.BASE_URL || 'http://localhost:3001';
  const dishName = `Test Dish ${Date.now()}`;
  const updatedName = `${dishName} (updated)`;
  const description = 'Descrição de teste';
  const price = '12.50';

  test('Criar novo prato', async ({ page }) => {
    // Vai para o formulário
    await page.goto(`${BASE_URL}/form`);
    await page.fill('input[name="name"]', dishName);
    await page.fill('textarea[name="description"]', description);
    await page.fill('input[name="price"]', price);
    // Submete
    await page.click('text=Criar prato');
    // Aguarda lista e verifica
    await page.waitForURL(`${BASE_URL}/`);
    await expect(page.locator(`text=${dishName}`)).toBeVisible();
  });

  test('Editar prato existente', async ({ page }) => {
    // Lista
    await page.goto(`${BASE_URL}/`);
    // Localiza o card que contém o nome
    const card = page.locator(`.grid div:has-text("${dishName}")`).first();
    // O link de editar é um <a> estilizado
    const editLink = card.locator('a:has-text("Editar")');
    await expect(editLink).toBeVisible();
    await editLink.click();
    // Form carrega com valor antigo
    await expect(page.locator('input[name="name"]')).toHaveValue(dishName);
    // Atualiza e submete
    await page.fill('input[name="name"]', updatedName);
    await page.click('text=Atualizar prato');
    // Verifica novo valor na lista
    await page.waitForURL(`${BASE_URL}/`);
    await expect(page.locator(`text=${updatedName}`)).toBeVisible();
  });

  test('Excluir prato', async ({ page }) => {
    await page.goto(`${BASE_URL}/`);
    const card = page.locator(`.grid div:has-text("${updatedName}")`).first();
    const deleteBtn = card.locator('button:has-text("Excluir")');
    await expect(deleteBtn).toBeVisible();
    await deleteBtn.click();
    // O card deve desaparecer
    await expect(page.locator(`text=${updatedName}`)).toHaveCount(0);
  });
});
